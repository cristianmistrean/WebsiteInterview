window.onload = function () {
    formTabFunction();

}

function formTabFunction() {
    const formTab = document.querySelector(".form-tab");
    console.log(formTab.classList.contains("show"));
    if (formTab) {
      formTab.addEventListener("click", () => {
        console.log("clicked");
        if (formTab.classList.contains("show")) {
          formTab.classList.remove("show");
        } else {
          formTab.classList.add("show");
        }
      });
    }
}
